# Shop Hisaab — Android v0.2

Android-first internal shop accounting app for a sweets & bakery business.

## Current interface
- Home dashboard
- Fast item search
- Stock IN
- Stock OUT / sale
- New Item / Variant
- Bhai Sajid ka Hisaab
- Reports hub
- More / adjustments hub
- Daily closing cash-difference screen
- Local SQLite database

## Planned accounting modules
- Full Bhai Sajid ledger and settlement
- Expected vs actual cash with traceable difference reasons
- Item-wise realized profit and monthly P&L
- Discount, customer return, wastage, sample/checking accounting
- Expiry and batch/FIFO handling
- Company-wise dashboard
- Low-stock alerts
- Daily/monthly report export and backup/restore

The project is designed as a base for incremental updates without rebuilding the data model from zero.
