package com.shop.hisaab;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.*;
import android.database.Cursor;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db; LinearLayout root, content, bottom;
    int green=Color.rgb(0,170,85), dark=Color.rgb(17,34,48), soft=Color.rgb(244,247,249), red=Color.rgb(220,60,70), blue=Color.rgb(52,96,210), orange=Color.rgb(238,145,25);

    @Override public void onCreate(Bundle b){ super.onCreate(b); db=new DB(this); showHome(); }

    TextView text(String s,float size){ TextView t=new TextView(this); t.setText(s);t.setTextSize(size);t.setTextColor(dark);t.setPadding(18,12,18,12);return t; }
    TextView title(String s){ TextView t=text(s,22);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setTextColor(Color.WHITE);t.setPadding(18,16,18,16);t.setBackgroundColor(dark);return t; }
    Button button(String s){ Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b; }
    LinearLayout card(){ LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(10,10,10,10);c.setBackgroundColor(Color.WHITE);return c; }
    void base(String heading){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(soft);
        TextView h=title(heading);root.addView(h,new LinearLayout.LayoutParams(-1,-2));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(10,8,10,12);
        ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        bottom=new LinearLayout(this);bottom.setPadding(4,2,4,2);bottom.setBackgroundColor(Color.WHITE);
        String[] ns={"Home","Search","IN","OUT","More"};
        for(String n:ns){Button x=button(n);bottom.addView(x,new LinearLayout.LayoutParams(0,58,1));x.setOnClickListener(v->{if(n.equals("Home"))showHome();else if(n.equals("Search"))showSearch();else if(n.equals("IN"))showMovement("IN");else if(n.equals("OUT"))showMovement("OUT");else showMore();});}
        root.addView(bottom);setContentView(root);
    }
    TextView stat(String top,String value,int color){ TextView t=text(top+"\n"+value,15);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setTextColor(color);t.setBackgroundColor(Color.WHITE);return t; }

    void showHome(){
        base("Shop Hisaab  •  Aaj");
        LinearLayout row1=new LinearLayout(this);row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(stat("Expected Cash","Rs. "+money(db.salesTotal()),blue),new LinearLayout.LayoutParams(0,92,1));
        row1.addView(stat("Cash Balance","Rs. "+money(db.cashBalance()),green),new LinearLayout.LayoutParams(0,92,1));content.addView(row1);
        LinearLayout row2=new LinearLayout(this);row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(stat("Stock Cost","Rs. "+money(db.totalStockValue()),dark),new LinearLayout.LayoutParams(0,92,1));
        row2.addView(stat("Low Stock",""+db.lowStockCount(),red),new LinearLayout.LayoutParams(0,92,1));content.addView(row2);
        content.addView(text("Quick Actions",18));
        LinearLayout q1=new LinearLayout(this);q1.setOrientation(LinearLayout.HORIZONTAL);
        addAction(q1,"🔎\nSearch",v->showSearch());addAction(q1,"📥\nStock IN",v->showMovement("IN"));addAction(q1,"📤\nStock OUT",v->showMovement("OUT"));content.addView(q1);
        LinearLayout q2=new LinearLayout(this);q2.setOrientation(LinearLayout.HORIZONTAL);
        addAction(q2,"💰\nBhai Sajid",v->showSajid());addAction(q2,"📊\nReports",v->showReports());addAction(q2,"•••\nMore",v->showMore());content.addView(q2);
        LinearLayout notice=card();notice.addView(text("Aaj ka focus",16));notice.addView(text("Search → IN/OUT → special adjustment sirf zaroorat par.\nBaqi stock, cash aur profit ka hisaab app karega.",15));content.addView(notice);
        Button add=button("+ New Item / Variant");content.addView(add);add.setOnClickListener(v->newItem());
    }
    void addAction(LinearLayout row,String s,View.OnClickListener l){Button b=button(s);row.addView(b,new LinearLayout.LayoutParams(0,78,1));b.setOnClickListener(l);}

    void showSearch(){
        base("Search Items");
        EditText q=new EditText(this);q.setHint("Oreo, Pepsi, 1.5L, company...");q.setSingleLine(true);content.addView(q);
        TextView count=text("0 items",13);content.addView(count);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable run=()->{list.removeAllViews();int n=0;Cursor c=db.search(q.getText().toString());while(c.moveToNext()){n++;addItemRow(list,c);}c.close();count.setText(n+" items found");};
        q.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){run.run();}public void afterTextChanged(Editable e){}});run.run();
    }
    void addItemRow(LinearLayout list,Cursor c){
        long id=c.getLong(0);String name=c.getString(1),brand=c.getString(2),variant=c.getString(3),unit=c.getString(4);double rate=c.getDouble(5),cost=c.getDouble(6),min=c.getDouble(7),st=c.getDouble(8);
        LinearLayout r=card();String label=(brand==null?"":brand+" • ")+name+(variant==null||variant.isEmpty()?"":" • "+variant);
        r.addView(text(label,17));TextView d=text("Stock: "+num(st)+" "+unit+"   |   Sale: Rs."+money(rate)+"   |   Cost: Rs."+money(cost),14);r.addView(d);if(st<=min)r.addView(text("⚠ Low stock — minimum "+num(min),13));
        list.addView(r);r.setOnClickListener(v->itemActions(id,label,rate,unit));
    }
    void itemActions(long id,String label,double rate,String unit){new AlertDialog.Builder(this).setTitle(label).setItems(new String[]{"Stock IN","Stock OUT","View / Edit"},(d,w)->{if(w==0)movementDialog(id,"IN",rate,unit);else if(w==1)movementDialog(id,"OUT",rate,unit);else showItemDetails(id,label);}).show();}
    void showItemDetails(long id,String label){base("Item Details");content.addView(text(label,21));content.addView(text("Item ka full stock, rate, cost aur movement history yahan show hogi.\n\nIs section mein next phase mein batch/expiry bhi attach hogi.",15));Button b=button("Stock IN / OUT");content.addView(b);b.setOnClickListener(v->movementDialog(id,"IN",0,"unit"));}

    void showMovement(String type){
        base(type.equals("IN")?"Stock IN":"Stock OUT");content.addView(text(type.equals("IN")?"Naya maal receive ho to yahan sirf item + quantity enter karo.":"Sale/maal OUT ho to item + quantity + actual sale amount enter karo.",15));
        EditText q=new EditText(this);q.setHint("Item search");q.setSingleLine(true);content.addView(q);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable run=()->{list.removeAllViews();Cursor c=db.search(q.getText().toString());while(c.moveToNext()){long id=c.getLong(0);String n=c.getString(1),br=c.getString(2),vr=c.getString(3),u=c.getString(4);double r=c.getDouble(5);Button x=button((br==null?"":br+" • ")+n+(vr==null||vr.isEmpty()?"":" • "+vr)+"\nRs."+money(r)+" / "+u);list.addView(x);x.setOnClickListener(z->movementDialog(id,type,r,u));}c.close();};
        q.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){run.run();}public void afterTextChanged(Editable e){}});run.run();
    }
    void movementDialog(long id,String type,double rate,String unit){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText qty=new EditText(this);qty.setHint("Quantity ("+unit+")");qty.setInputType(2|8192);box.addView(qty);
        EditText amt=new EditText(this);amt.setHint(type.equals("OUT")?"Actual sale amount":"Purchase amount (optional)");amt.setInputType(2|8192);box.addView(amt);
        new AlertDialog.Builder(this).setTitle(type.equals("IN")?"Stock IN":"Stock OUT").setView(box).setPositiveButton("Save",(d,w)->{double q=parse(qty.getText().toString()),a=parse(amt.getText().toString());if(q>0)db.movement(id,type,q,a, type.equals("OUT")?"Sale":"Received");Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();showHome();}).setNegativeButton("Cancel",null).show();
    }
    void newItem(){
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);EditText[] e=new EditText[8];String[] h={"Item name","Company / Brand","Variant / Size / Price tag","Unit: piece / kg / pack","Selling rate","Purchase cost","Minimum stock","Opening stock"};
        for(int i=0;i<e.length;i++){e[i]=new EditText(this);e[i].setHint(h[i]);b.addView(e[i]);}
        new AlertDialog.Builder(this).setTitle("New Item / Variant").setView(b).setPositiveButton("Save",(d,w)->{db.addItem(e[0].getText().toString(),e[1].getText().toString(),e[2].getText().toString(),e[3].getText().toString(),parse(e[4].getText().toString()),parse(e[5].getText().toString()),parse(e[6].getText().toString()),parse(e[7].getText().toString()));Toast.makeText(this,"Item saved",Toast.LENGTH_SHORT).show();showHome();}).setNegativeButton("Cancel",null).show();
    }

    void showSajid(){base("Bhai Sajid ka Hisaab");LinearLayout c=card();c.addView(text("Current Balance",15));c.addView(text("Rs. 0",28));c.addView(text("Yahan Bhai Sajid se maal, return aur payment ka complete hisaab rahega.",14));content.addView(c);
        Button in=button("+ Maal IN from Sajid");Button pay=button("− Payment to Sajid");Button ret=button("↩ Return to Sajid");content.addView(in);content.addView(pay);content.addView(ret);
        in.setOnClickListener(v->simpleAmount("Maal IN from Sajid","IN"));pay.setOnClickListener(v->simpleAmount("Payment to Sajid","OUT"));ret.setOnClickListener(v->simpleAmount("Return to Sajid","RETURN"));
    }
    void simpleAmount(String title,String type){EditText e=new EditText(this);e.setHint("Amount Rs.");e.setInputType(2|8192);new AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("Save",(d,w)->{double a=parse(e.getText().toString());if(a>0)db.cash(type.equals("IN")?"OUT":"OUT",a,title);showSajid();}).setNegativeButton("Cancel",null).show();}

    void showReports(){base("Reports");String[] rs={"📊 Daily Report","📅 Monthly Report","💹 Item-wise Profit","📦 Stock Report","🏢 Company-wise Stock","⚠ Low Stock","⏰ Expiry / Batch","💵 Cash Report"};for(String s:rs){Button b=button(s);content.addView(b);b.setOnClickListener(v->Toast.makeText(this,"Is report ka detailed module next build mein active hoga.",Toast.LENGTH_SHORT).show());}content.addView(text("Current totals\nSales: Rs."+money(db.salesTotal())+"\nStock cost: Rs."+money(db.totalStockValue())+"\nItems: "+db.itemCount(),16));}
    void showMore(){base("More");String[] rs={"🟢 Sample / Checking","🔴 Wastage / Damage","↩ Customer Return","↩ Return to Sajid","💵 Cash IN / OUT","🧾 Daily Closing","🔔 Low Stock & Expiry Alerts","💾 Backup / Restore","⚙ Settings"};for(String s:rs){Button b=button(s);content.addView(b);b.setOnClickListener(v->{if(s.contains("Sample"))simpleAmount("Sample / Checking value","OUT");else if(s.contains("Cash"))cashDialog();else if(s.contains("Daily"))closing();else Toast.makeText(this,s+" — next module",Toast.LENGTH_SHORT).show();});}}
    void cashDialog(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);EditText a=new EditText(this);a.setHint("Amount Rs.");EditText n=new EditText(this);n.setHint("Note");b.addView(a);b.addView(n);new AlertDialog.Builder(this).setTitle("Cash IN / OUT").setView(b).setPositiveButton("Cash IN",(d,w)->{db.cash("IN",parse(a.getText().toString()),n.getText().toString());showHome();}).setNeutralButton("Cash OUT",(d,w)->{db.cash("OUT",parse(a.getText().toString()),n.getText().toString());showHome();}).setNegativeButton("Cancel",null).show();}
    void closing(){base("Daily Closing");content.addView(text("Expected Cash\nRs. "+money(db.salesTotal()),24));EditText actual=new EditText(this);actual.setHint("Physical cash counted");actual.setInputType(2|8192);content.addView(actual);Button b=button("Calculate Difference");content.addView(b);TextView out=text("",18);content.addView(out);b.setOnClickListener(v->{double x=parse(actual.getText().toString());out.setText("Difference = Rs. "+money(x-db.salesTotal())+"\n\nAgar difference aaye to app related transactions check karne mein help karega.");});}
    double parse(String s){try{return Double.parseDouble(s.trim());}catch(Exception e){return 0;}}
    String money(double x){return String.format(Locale.US,"%,.2f",x);}String num(double x){return String.format(Locale.US,"%.2f",x).replaceAll("\\.00$","");}
}
