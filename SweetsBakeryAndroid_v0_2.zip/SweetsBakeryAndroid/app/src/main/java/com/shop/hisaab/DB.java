package com.shop.hisaab;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DB extends SQLiteOpenHelper {
    public DB(Context c) { super(c, "shop_hisaab.db", null, 2); }

    public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,brand TEXT,variant TEXT,unit TEXT,rate REAL DEFAULT 0,cost REAL DEFAULT 0,min_stock REAL DEFAULT 0,stock REAL DEFAULT 0)");
        d.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT,item_id INTEGER,type TEXT,qty REAL,amount REAL,note TEXT,created_at TEXT)");
        d.execSQL("CREATE TABLE cash(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,amount REAL,note TEXT,created_at TEXT)");
    }
    public void onUpgrade(SQLiteDatabase d,int oldV,int newV) { }

    public Cursor search(String q) {
        return getReadableDatabase().rawQuery(
            "SELECT id,name,brand,variant,unit,rate,cost,min_stock,stock FROM items WHERE name LIKE ? OR brand LIKE ? OR variant LIKE ? OR brand LIKE ? ORDER BY name,variant",
            new String[]{"%"+q+"%","%"+q+"%","%"+q+"%","%"+q+"%"});
    }

    public long addItem(String name,String brand,String variant,String unit,double rate,double cost,double min,double stock) {
        ContentValues v=new ContentValues();
        v.put("name",name); v.put("brand",brand); v.put("variant",variant); v.put("unit",unit);
        v.put("rate",rate); v.put("cost",cost); v.put("min_stock",min); v.put("stock",stock);
        long id=getWritableDatabase().insert("items",null,v);
        if(stock>0) movement(id,"IN",stock,0,"Opening stock");
        return id;
    }

    public void movement(long id,String type,double qty,double amount,String note) {
        SQLiteDatabase d=getWritableDatabase();
        Cursor c=d.rawQuery("SELECT stock FROM items WHERE id=?",new String[]{""+id});
        double old=0; if(c.moveToFirst()) old=c.getDouble(0); c.close();
        double next= type.equals("IN") ? old+qty : old-qty;
        if(next<0) next=0;
        ContentValues iv=new ContentValues(); iv.put("stock",next);
        d.update("items",iv,"id=?",new String[]{""+id});
        ContentValues m=new ContentValues();
        m.put("item_id",id);m.put("type",type);m.put("qty",qty);m.put("amount",amount);
        m.put("note",note);m.put("created_at",now()); d.insert("movements",null,m);
        if(type.equals("OUT") && amount!=0) cash("IN",amount,"Sale");
    }

    public void cash(String type,double amount,String note) {
        ContentValues v=new ContentValues(); v.put("type",type);v.put("amount",amount);v.put("note",note);v.put("created_at",now());
        getWritableDatabase().insert("cash",null,v);
    }

    public double cashBalance() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN type='IN' THEN amount ELSE -amount END),0) FROM cash",null);
        double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public double totalStockValue() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(stock*cost),0) FROM items",null);
        double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
    }
    public int itemCount() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items",null);int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x; }
    public int lowStockCount() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM items WHERE stock<=min_stock",null);int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();return x; }
    public double salesTotal() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(amount),0) FROM movements WHERE type='OUT'",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x; }
    public double purchaseValue() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN type='IN' THEN qty*COALESCE((SELECT cost FROM items i WHERE i.id=m.item_id),0) ELSE 0 END),0) FROM movements m",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x; }
    public double soldCost() { Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN type='OUT' THEN qty*COALESCE((SELECT cost FROM items i WHERE i.id=m.item_id),0) ELSE 0 END),0) FROM movements m",null);double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x; }
    public Cursor allItems() { return getReadableDatabase().rawQuery("SELECT id,name,brand,variant,unit,rate,cost,min_stock,stock FROM items ORDER BY brand,name,variant",null); }
    private String now(){return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(new java.util.Date());}
}
